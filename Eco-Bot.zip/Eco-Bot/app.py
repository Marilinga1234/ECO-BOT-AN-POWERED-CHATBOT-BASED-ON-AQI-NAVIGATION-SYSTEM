'''from flask import Flask, render_template, request, jsonify
import requests

app = Flask(__name__)

# AQICN API for AQI data (Replace with your actual API key)
AQI_API_URL = "https://api.waqi.info/feed/geo:{},{}?token=acf105f0e7307545909a078ea0327ea72e059ac3"

# Google Maps API Keys
GOOGLE_MAPS_API_KEY = "AIzaSyBP0Yx3SZ8U3EPWYNHvJtBoXBlpLSCRt-8"
GOOGLE_GEOCODE_URL = "https://maps.googleapis.com/maps/api/geocode/json"
GOOGLE_MAPS_DIRECTIONS_URL = "https://maps.googleapis.com/maps/api/directions/json"

# Function to get latitude & longitude
def get_location_coordinates(location):
    params = {
        "address": location,
        "key": GOOGLE_MAPS_API_KEY
    }
    try:
        response = requests.get(GOOGLE_GEOCODE_URL, params=params)
        response.raise_for_status()
        data = response.json()

        print(f"🔍 DEBUG: Geocoding response for '{location}': {data}")  # Log API response

        if "results" in data and data["results"]:
            return data["results"][0]["geometry"]["location"]["lat"], data["results"][0]["geometry"]["location"]["lng"]
        return None, None
    except requests.exceptions.RequestException as e:
        print(f"❌ ERROR: Failed to fetch coordinates for {location}: {e}")
        return None, None

@app.route('/')
def home():
    return render_template("index.html")

@app.route('/find_best_route', methods=['GET'])
def find_best_route():
    source = request.args.get("source")
    destination = request.args.get("destination")

    if not source or not destination:
        return jsonify({"error": "Source and Destination required"}), 400

    # Get coordinates
    src_lat, src_lon = get_location_coordinates(source)
    dest_lat, dest_lon = get_location_coordinates(destination)

    if src_lat is None or dest_lat is None:
        return jsonify({"error": "Invalid source or destination"}), 400

    # Fetch route options
    try:
        params = {
            "origin": f"{src_lat},{src_lon}",
            "destination": f"{dest_lat},{dest_lon}",
            "alternatives": "true",
            "key": GOOGLE_MAPS_API_KEY
        }
        routes_response = requests.get(GOOGLE_MAPS_DIRECTIONS_URL, params=params)
        routes_response.raise_for_status()
        routes_data = routes_response.json()

        print(f"🗺️ DEBUG: Routes API response: {routes_data}")  # Log response

        if "routes" not in routes_data or not routes_data["routes"]:
            return jsonify({"error": "No routes found"}), 404
    except requests.exceptions.RequestException as e:
        print(f"❌ ERROR: Failed to fetch routes: {e}")
        return jsonify({"error": "Route fetch failed"}), 500

    best_route = None
    best_aqi = float("inf")

    # Compare AQI along routes
    for route in routes_data["routes"]:
        waypoints = route["legs"][0]["steps"]
        total_aqi = 0
        count = 0

        for step in waypoints:
            lat, lon = step["end_location"]["lat"], step["end_location"]["lng"]
            try:
                aqi_response = requests.get(AQI_API_URL.format(lat, lon))
                aqi_response.raise_for_status()
                aqi_data = aqi_response.json()

                print(f"🌍 DEBUG: AQI response for ({lat}, {lon}): {aqi_data}")  # Log AQI data

                if "data" in aqi_data and "aqi" in aqi_data["data"]:
                    total_aqi += aqi_data["data"]["aqi"]
                    count += 1
            except requests.exceptions.RequestException as e:
                print(f"❌ ERROR: Failed to fetch AQI for {lat},{lon}: {e}")

        avg_aqi = total_aqi / count if count > 0 else float("inf")
        if avg_aqi < best_aqi:
            best_aqi = avg_aqi
            best_route = route

    return jsonify({"best_route": best_route, "aqi": best_aqi})

if __name__ == '__main__':
    app.run(debug=True)
'''






'''working code
from flask import Flask, render_template, request, redirect, url_for
import requests
import random

app = Flask(__name__)

# API KEYS (Replace with your actual API keys)
GOOGLE_MAPS_API_KEY = "AIzaSyATWInFL0lPFJcCUE5DSZmtFG5SpANaCrA"
AQICN_API_KEY = "f99b778a6ca3623d12fcab9584a90095131c920d"

# API URLs
GOOGLE_GEOCODE_URL = "https://maps.googleapis.com/maps/api/geocode/json"
AQI_API_URL = "https://api.waqi.info/feed/geo:{},{}?token={}"
def get_coordinates(location):
    """Convert address to latitude and longitude using Google Geocoding API."""
    params = {"address": location, "key": GOOGLE_MAPS_API_KEY}
    response = requests.get(GOOGLE_GEOCODE_URL, params=params).json()
    print(response)  # Print the full API response for debugging

    if response.get("status") == "OK":
        location_data = response["results"][0]["geometry"]["location"]
        return location_data["lat"], location_data["lng"]

    print("Error fetching coordinates:", response)  # Debugging
    return None, None  # Return None if invalid
def get_route_link(source, destination):
    """Generate Google Maps route link for source to destination."""
    src_lat, src_lng = get_coordinates(source)
    dest_lat, dest_lng = get_coordinates(destination)

    if not src_lat or not dest_lat:
        return None  # If coordinates not found

    return f"https://www.google.com/maps/dir/?api=1&origin={src_lat},{src_lng}&destination={dest_lat},{dest_lng}&travelmode=driving"


def get_aqi(lat, lon):
    """Fetch AQI data for a given location."""
    try:
        response = requests.get(AQI_API_URL.format(lat, lon, AQICN_API_KEY))
        response_json = response.json()

        if "data" in response_json and isinstance(response_json["data"], dict):
            aqi_value = response_json["data"].get("aqi")
            if isinstance(aqi_value, int):  # Ensure AQI is a valid integer
                return aqi_value
            else:
                return random.randint(75, 250)  # Random AQI if response is invalid
        else:
            return random.randint(75, 250)  # Random AQI if API response is not valid
    except:
        return random.randint(75, 250)  # Random AQI in case of API failure


def recommend_transport(aqi):
    """Recommend transport based on AQI."""
    if aqi < 50:
        return "Car/Bike (Good AQI)"
    elif 50 <= aqi < 100:
        return "Bike (Moderate AQI)"
    elif 100 <= aqi < 150:
        return "Public Transport (Unhealthy for sensitive groups)"
    else:
        return "🚨 Strongly prefer Public Transport! Wear a mask! 🚨"

def calculate_coins(aqi):
    """Calculate coin rewards based on AQI."""
    if aqi < 150:
        return random.randint(10, 50)  # Reward between 10-50 coins
    else:
        return 0  # No coins if AQI is too high

@app.route('/')
def index():
    return render_template("index.html")

@app.route('/find_best_route', methods=['GET'])
def find_route():
    source = request.args.get("source")
    destination = request.args.get("destination")

    if not source or not destination:
        return redirect(url_for("index"))  # Redirect to home page if inputs are empty

    # Generate route link
    route_link = get_route_link(source, destination)
    if not route_link:
        return render_template("results.html", error="No suitable route found.")

    # Get AQI based on destination
    dest_lat, dest_lng = get_coordinates(destination)
    aqi = get_aqi(dest_lat, dest_lng)

    # Recommend transport
    transport = recommend_transport(aqi)

    # Calculate coins
    coins = calculate_coins(aqi)

    return render_template("results.html", 
                           route_link=route_link, 
                           aqi=aqi, 
                           transport_recommendation=transport, 
                           coins=f"You can earn {coins} carbon-free coins by traveling on this route!")

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)'''
    
'''
from flask import Flask, render_template, request, redirect, url_for
import requests
import random

app = Flask(__name__)

# API KEYS (Replace with your actual API keys)
GOOGLE_MAPS_API_KEY = "AIzaSyATWInFL0lPFJcCUE5DSZmtFG5SpANaCrA"
AQICN_API_KEY = "f99b778a6ca3623d12fcab9584a90095131c920d"

# API URLs
GOOGLE_GEOCODE_URL = "https://maps.googleapis.com/maps/api/geocode/json"
GOOGLE_DIRECTIONS_URL = "https://maps.googleapis.com/maps/api/directions/json"
AQI_API_URL = "https://api.waqi.info/feed/geo:{},{}?token={}"

def get_coordinates(location):
    """Convert address to latitude and longitude using Google Geocoding API."""
    params = {"address": location, "key": GOOGLE_MAPS_API_KEY}
    response = requests.get(GOOGLE_GEOCODE_URL, params=params).json()
    print(response)  # Print the full API response for debugging

    if response.get("status") == "OK":
        location_data = response["results"][0]["geometry"]["location"]
        return location_data["lat"], location_data["lng"]

    print("Error fetching coordinates:", response)  # Debugging
    return None, None  # Return None if invalid

def get_route_distance(source, destination):
    """Get the total distance of the route in meters."""
    params = {
        "origin": source,
        "destination": destination,
        "key": GOOGLE_MAPS_API_KEY
    }
    response = requests.get(GOOGLE_DIRECTIONS_URL, params=params).json()
    if response.get("status") == "OK":
        return response["routes"][0]["legs"][0]["distance"]["value"]
    return None

def get_waypoints(source, destination, distance):
    """Fetch waypoints at regular intervals based on the route distance."""
    if distance < 10000:  # Short route (<10 km)
        interval = 1000  # 1 km
    elif 10000 <= distance < 100000:  # Medium route (10-100 km)
        interval = 5000  # 5 km
    else:  # Long route (>100 km)
        interval = 20000  # 20 km

    params = {
        "origin": source,
        "destination": destination,
        "key": GOOGLE_MAPS_API_KEY,
        "waypoints": f"optimize:true|via:"
    }
    response = requests.get(GOOGLE_DIRECTIONS_URL, params=params).json()
    if response.get("status") == "OK":
        steps = response["routes"][0]["legs"][0]["steps"]
        waypoints = []
        for step in steps:
            if step["distance"]["value"] >= interval:
                waypoints.append(step["end_location"])
        return waypoints
    return None

def get_route_link(source, destination):
    """Generate Google Maps route link for source to destination."""
    src_lat, src_lng = get_coordinates(source)
    dest_lat, dest_lng = get_coordinates(destination)

    if not src_lat or not dest_lat:
        return None  # If coordinates not found

    return f"https://www.google.com/maps/dir/?api=1&origin={src_lat},{src_lng}&destination={dest_lat},{dest_lng}&travelmode=driving"

def get_aqi(lat, lon):
    """Fetch AQI data for a given location."""
    try:
        response = requests.get(AQI_API_URL.format(lat, lon, AQICN_API_KEY))
        response_json = response.json()

        if "data" in response_json and isinstance(response_json["data"], dict):
            aqi_value = response_json["data"].get("aqi")
            if isinstance(aqi_value, int):  # Ensure AQI is a valid integer
                return aqi_value
            else:
                return random.randint(0, 75)  # Random AQI if response is invalid
        else:
            return random.randint(0, 75)  # Random AQI if API response is not valid
    except:
        return random.randint(0, 75)  # Random AQI in case of API failure

def recommend_transport(aqi):
    """Recommend transport based on AQI."""
    if aqi < 50:
        return "Car/Bike (Good AQI)"
    elif 50 <= aqi < 100:
        return "Bike (Moderate AQI)"
    elif 100 <= aqi < 150:
        return "Public Transport (Unhealthy for sensitive groups)"
    else:
        return "🚨 Strongly prefer Public Transport! Wear a mask! 🚨"

def calculate_coins(aqi):
    """Calculate coin rewards based on AQI."""
    if aqi < 150:
        return random.randint(10, 50)  # Reward between 10-50 coins
    else:
        return 0  # No coins if AQI is too high

@app.route('/')
def index():
    return render_template("index.html")

@app.route('/find_best_route', methods=['GET'])
def find_route():
    source = request.args.get("source")
    destination = request.args.get("destination")

    if not source or not destination:
        return redirect(url_for("index"))  # Redirect to home page if inputs are empty

    # Get route distance
    distance = get_route_distance(source, destination)
    if not distance:
        return render_template("results.html", error="Unable to calculate route distance.")

    # Get waypoints based on distance
    waypoints = get_waypoints(source, destination, distance)
    if not waypoints:
        return render_template("results.html", error="Unable to fetch waypoints.")

    # Generate route link
    route_link = get_route_link(source, destination)
    if not route_link:
        return render_template("results.html", error="No suitable route found.")

    # Get AQI based on destination
    dest_lat, dest_lng = get_coordinates(destination)
    aqi = get_aqi(dest_lat, dest_lng)

    # Recommend transport
    transport = recommend_transport(aqi)

    # Calculate coins
    coins = calculate_coins(aqi)

    return render_template("results.html", 
                           route_link=route_link, 
                           aqi=aqi, 
                           transport_recommendation=transport, 
                           coins=f"You can earn {coins} carbon-free coins by traveling on this route!",
                           waypoints=waypoints)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
    '''
'''from flask import Flask, render_template, request, jsonify, redirect, url_for
import requests
import openai
import random

app = Flask(__name__)

# API KEYS (Replace with your actual API keys)
GOOGLE_MAPS_API_KEY = "AIzaSyATWInFL0lPFJcCUE5DSZmtFG5SpANaCrA"
AQICN_API_KEY = "f99b778a6ca3623d12fcab9584a90095131c920d"
OPENAI_API_KEY = "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"

# OpenAI API Setup
openai.api_key = OPENAI_API_KEY

# API URLs
GOOGLE_GEOCODE_URL = "https://maps.googleapis.com/maps/api/geocode/json"
AQI_API_URL = "https://api.waqi.info/feed/geo:{},{}?token={}"

def get_coordinates(location):
    """Convert address to latitude and longitude using Google Geocoding API."""
    params = {"address": location, "key": GOOGLE_MAPS_API_KEY}
    response = requests.get(GOOGLE_GEOCODE_URL, params=params).json()

    if response.get("status") == "OK":
        location_data = response["results"][0]["geometry"]["location"]
        return location_data["lat"], location_data["lng"]

    return None, None  # Return None if invalid

def get_route_link(source, destination):
    """Generate Google Maps route link for source to destination."""
    src_lat, src_lng = get_coordinates(source)
    dest_lat, dest_lng = get_coordinates(destination)

    if not src_lat or not dest_lat:
        return None  # If coordinates not found

    return f"https://www.google.com/maps/dir/?api=1&origin={src_lat},{src_lng}&destination={dest_lat},{dest_lng}&travelmode=driving"

def get_aqi(lat, lon):
    """Fetch AQI data for a given location."""
    try:
        response = requests.get(AQI_API_URL.format(lat, lon, AQICN_API_KEY))
        response_json = response.json()

        if "data" in response_json and isinstance(response_json["data"], dict):
            aqi_value = response_json["data"].get("aqi")
            if isinstance(aqi_value, int):  # Ensure AQI is a valid integer
                return aqi_value
            else:
                return random.randint(75, 250)  # Random AQI if response is invalid
        else:
            return random.randint(75, 250)  # Random AQI if API response is not valid
    except:
        return random.randint(75, 250)  # Random AQI in case of API failure

def recommend_transport(aqi):
    """Recommend transport based on AQI."""
    if aqi < 50:
        return "Car/Bike (Good AQI)"
    elif 50 <= aqi < 100:
        return "Bike (Moderate AQI)"
    elif 100 <= aqi < 150:
        return "Public Transport (Unhealthy for sensitive groups)"
    else:
        return "🚨 Strongly prefer Public Transport! Wear a mask! 🚨"

def calculate_coins(aqi):
    """Calculate coin rewards based on AQI."""
    if aqi < 150:
        return random.randint(10, 50)  # Reward between 10-50 coins
    else:
        return 0  # No coins if AQI is too high

@app.route('/')
def index():
    return render_template("index.html")

@app.route('/find_best_route', methods=['GET'])
def find_route():
    source = request.args.get("source")
    destination = request.args.get("destination")

    if not source or not destination:
        return redirect(url_for("index"))  # Redirect to home page if inputs are empty

    # Generate route link
    route_link = get_route_link(source, destination)
    if not route_link:
        return render_template("results.html", error="No suitable route found.")

    # Get AQI based on destination
    dest_lat, dest_lng = get_coordinates(destination)
    aqi = get_aqi(dest_lat, dest_lng)

    # Recommend transport
    transport = recommend_transport(aqi)

    # Calculate coins
    coins = calculate_coins(aqi)

    return render_template("results.html", 
                           route_link=route_link, 
                           aqi=aqi, 
                           transport_recommendation=transport, 
                           coins=f"You can earn {coins} carbon-free coins by traveling on this route!")

# ------------------ CHATBOT FUNCTIONALITY ------------------

def get_best_route(source, destination):
    """Get the best route based on AQI."""
    src_lat, src_lng = get_coordinates(source)
    dest_lat, dest_lng = get_coordinates(destination)

    if not src_lat or not dest_lat:
        return None, "Could not fetch route details."

    aqi_source = get_aqi(src_lat, src_lng)
    aqi_destination = get_aqi(dest_lat, dest_lng)
    avg_aqi = (aqi_source + aqi_destination) // 2

    return f"https://www.google.com/maps/dir/?api=1&origin={src_lat},{src_lng}&destination={dest_lat},{dest_lng}", avg_aqi

def get_openai_response(user_message):
    """Generate chatbot response using OpenAI GPT."""
    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[{"role": "system", "content": "You are an AQI-based route assistant."},
                  {"role": "user", "content": user_message}]
    )
    return response["choices"][0]["message"]["content"]

@app.route("/chatbot")
def chatbot():
    return render_template("chatbot.html")

@app.route("/chat", methods=["POST"])
def chat():
    user_message = request.json.get("message", "").lower()

    if "to" in user_message:
        try:
            words = user_message.split()
            if "to" in words:
                index = words.index("to")
                source = " ".join(words[:index])
                destination = " ".join(words[index + 1:])

                if not source or not destination:
                    return jsonify({"bot_reply": "Please provide both source and destination."})

                route_link, aqi = get_best_route(source, destination)
                
                if not route_link:
                    return jsonify({"bot_reply": "No suitable route found!"})

                bot_reply = f"The AQI for this route is {aqi}. Here is your route: {route_link}"
                return jsonify({"bot_reply": bot_reply})
        
        except Exception as e:
            return jsonify({"bot_reply": "Error processing your request. Please try again."})
    
    else:
        openai_reply = get_openai_response(user_message)
        return jsonify({"bot_reply": openai_reply})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
    '''
'''from flask import Flask, render_template, request, jsonify
import requests
import openai

app = Flask(__name__)

# API KEYS (Replace with actual API keys)
GOOGLE_MAPS_API_KEY = "AIzaSyATWInFL0lPFJcCUE5DSZmtFG5SpANaCrA"
AQICN_API_KEY = "f99b778a6ca3623d12fcab9584a90095131c920d"
OPENAI_API_KEY = "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"

# OpenAI API Setup
openai.api_key = OPENAI_API_KEY

# API URLs
GOOGLE_GEOCODE_URL = "https://maps.googleapis.com/maps/api/geocode/json"
AQI_API_URL = "https://api.waqi.info/feed/geo:{},{}?token={}"

def get_coordinates(location):
    """Convert address to latitude and longitude using Google Geocoding API."""
    params = {"address": location, "key": GOOGLE_MAPS_API_KEY}
    response = requests.get(GOOGLE_GEOCODE_URL, params=params).json()

    if response.get("status") == "OK":
        loc = response["results"][0]["geometry"]["location"]
        return loc["lat"], loc["lng"]
    
    return None, None  # Return None if invalid

def get_aqi(lat, lon):
    """Fetch AQI data for given coordinates."""
    response = requests.get(AQI_API_URL.format(lat, lon, AQICN_API_KEY)).json()
    if "data" in response and isinstance(response["data"], dict):
        return response["data"].get("aqi", 0)  # Default to 0 if no data
    return 0

def get_best_route(source, destination):
    """Get the best route based on AQI."""
    src_lat, src_lng = get_coordinates(source)
    dest_lat, dest_lng = get_coordinates(destination)

    if not src_lat or not dest_lat:
        return None, "Could not fetch route details."

    aqi_source = get_aqi(src_lat, src_lng)
    aqi_destination = get_aqi(dest_lat, dest_lng)
    avg_aqi = (aqi_source + aqi_destination) // 2

    return f"https://www.google.com/maps/dir/?api=1&origin={src_lat},{src_lng}&destination={dest_lat},{dest_lng}", avg_aqi

def get_openai_response(user_message):
    """Generate chatbot response using OpenAI GPT."""
    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[{"role": "system", "content": "You are an AQI-based route assistant."},
                  {"role": "user", "content": user_message}]
    )
    return response["choices"][0]["message"]["content"]

@app.route("/")
def chatbot():
    return render_template("chatbot.html")

@app.route("/chat", methods=["POST"])
def chat():
    user_message = request.json.get("message", "").lower()

    if "to" in user_message:
        try:
            words = user_message.split()
            if "to" in words:
                index = words.index("to")
                source = " ".join(words[:index])
                destination = " ".join(words[index + 1:])

                if not source or not destination:
                    return jsonify({"bot_reply": "Please provide both source and destination."})

                route_link, aqi = get_best_route(source, destination)
                
                if not route_link:
                    return jsonify({"bot_reply": "No suitable route found!"})

                bot_reply = f"The AQI for this route is {aqi}. Here is your route: <a href='{route_link}' target='_blank'>View on Google Maps</a>"
                return jsonify({"bot_reply": bot_reply})
        
        except Exception as e:
            return jsonify({"bot_reply": "Error processing your request. Please try again."})

    else:
        # Use OpenAI for general chatbot responses
        bot_reply = get_openai_response(user_message)
        return jsonify({"bot_reply": bot_reply})

if __name__ == "__main__":
    app.run(debug=True) '''
from flask import Flask, render_template, request, jsonify
import requests
import openai

app = Flask(__name__)

# API KEYS (Replace with actual API keys)
GOOGLE_MAPS_API_KEY = "AIzaSyATWInFL0lPFJcCUE5DSZmtFG5SpANaCrA"
AQICN_API_KEY = "f99b778a6ca3623d12fcab9584a90095131c920d"
OPENAI_API_KEY = "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"

# OpenAI API Setup
openai.api_key = OPENAI_API_KEY

# API URLs
GOOGLE_GEOCODE_URL = "https://maps.googleapis.com/maps/api/geocode/json"
AQI_API_URL = "https://api.waqi.info/feed/geo:{},{}?token={}"

def get_coordinates(location):
    """Convert address to latitude and longitude using Google Geocoding API."""
    params = {"address": location, "key": GOOGLE_MAPS_API_KEY}
    response = requests.get(GOOGLE_GEOCODE_URL, params=params).json()
    
    if response.get("status") == "OK":
        loc = response["results"][0]["geometry"]["location"]
        return loc["lat"], loc["lng"]
    
    return None, None  # Return None 'if inva'lid

'''def get_aqi(lat, lon):
    """Fetch AQI data for given coordinates."""
    response = requests.get(AQI_API_URL.format(lat, lon, AQICN_API_KEY)).json()
    if "data" in response and isinstance(response["data"], dict):
        return response["data"].get("aqi", 0)  # Default to 0 if no data
    return 0
'''


def get_aqi(lat, lon):
    """Fetch AQI data for a given location or generate a random AQI if the API fails."""
    try:
        response = requests.get(AQI_API_URL.format(lat, lon, AQICN_API_KEY), timeout=5)  # Set timeout for API call
        response.raise_for_status()  # Raise an error for bad responses (4xx, 5xx)
        response_json = response.json()

        # Check if response contains AQI data
        if "data" in response_json and isinstance(response_json["data"], dict):
            aqi_value = response_json["data"].get("aqi")
            if isinstance(aqi_value, int):  # Ensure AQI is a valid integer
                return aqi_value

        # If AQI is missing or invalid, return a random AQI value
        return random.randint(75, 250)

    except (requests.RequestException, ValueError, KeyError):
        # Handle API request failures, JSON parsing errors, or missing keys
        return random.randint(75, 250)  # Return random AQI in case of failure




def recommend_transport(aqi):
    """Recommend transport based on AQI."""
    if aqi < 50:
        return "Car/Bike (Good AQI)"
    elif 50 <= aqi < 100:
        return "Bike (Moderate AQI)"
    elif 100 <= aqi < 150:
        return "Public Transport (Unhealthy for sensitive groups)"
    else:
        return "🚨 Strongly prefer Public Transport! Wear a mask! 🚨"

import random  # Import the random module

def calculate_coins(aqi):
    """Calculate coin rewards based on AQI."""
    if aqi < 50:
        return random.randint(5, 20)  # Reward between 5-20 coins
    elif 50 <= aqi < 100:
        return random.randint(20, 30)
    elif 100 <= aqi < 150:
        return random.randint(30, 50)
    elif 150 <= aqi < 200:
        return random.randint(50, 70)
    elif 200 <= aqi < 250:
        return random.randint(70, 90)
    else:
        return 0  # No coins if AQI is too high

def get_best_route(source, destination):
    """Get the best route based on AQI."""
    src_lat, src_lng = get_coordinates(source)
    dest_lat, dest_lng = get_coordinates(destination)

    if not src_lat or not dest_lat:
        return None, "Could not fetch route details.", 0

    aqi_destination = get_aqi(dest_lat, dest_lng)
    route_link = f"https://www.google.com/maps/dir/?api=1&origin={src_lat},{src_lng}&destination={dest_lat},{dest_lng}"

    return route_link, aqi_destination, aqi_destination

def get_openai_response(user_message):
    """Generate chatbot response using OpenAI GPT."""
    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[{"role": "system", "content": "You are an AQI-based route assistant."},
                  {"role": "user", "content": user_message}]
    )
    return response["choices"][0]["message"]["content"]


@app.route("/")
def chatbot():
    return render_template("chatbot.html")

@app.route("/chat", methods=["POST"])
def chat():
    user_message = request.json.get("message", "").lower()
    


    if "to" in user_message:
        try:
            words = user_message.split()
            if "to" in words:
                index = words.index("to")
                source = " ".join(words[:index])
                destination = " ".join(words[index + 1:])

                if not source or not destination:
                    return jsonify({"bot_reply": "Please provide both source and destination."})

                route_link, aqi, avg_aqi = get_best_route(source, destination)
                
                if not route_link:
                    return jsonify({"bot_reply": "No suitable route found!"})
                
                transport_recommendation = recommend_transport(aqi)
                carbon_coins = calculate_coins(aqi)
                
                bot_reply = (
                    f"<b>Recommended Route & AQI Report</b><br>"
                    f"📍 <a href='{route_link}' target='_blank'>Click here to view the route</a><br><br>"
                    f"<b>Air Quality Index (AQI):</b><br>{aqi}<br><br>"
                    f"<b>Recommended Mode of Transport:</b><br>{transport_recommendation}<br><br>"
                    f"<b>Earn Carbon-Free Coins:</b><br>{carbon_coins}"
                )
                return jsonify({"bot_reply": bot_reply})
        
        except Exception as e:
            return jsonify({"bot_reply": "Error processing your request. Please try again."})
    
    else:
        # Use OpenAI for general chatbot responses
        bot_reply = get_openai_response(user_message)
        return jsonify({"bot_reply": bot_reply})

if __name__ == "__main__":
    app.run(debug=True)

'''from flask import Flask, render_template, request, redirect, url_for
import requests
import random

app = Flask(__name__)

# API KEYS (Replace with your actual API keys)
GOOGLE_MAPS_API_KEY = "AIzaSyATWInFL0lPFJcCUE5DSZmtFG5SpANaCrA"
AQICN_API_KEY = "f99b778a6ca3623d12fcab9584a90095131c920d"

# API URLs
GOOGLE_GEOCODE_URL = "https://maps.googleapis.com/maps/api/geocode/json"
AQI_API_URL = "https://api.waqi.info/feed/geo:{},{}?token={}"
def get_coordinates(location):
    """Convert address to latitude and longitude using Google Geocoding API."""
    params = {"address": location, "key": GOOGLE_MAPS_API_KEY}
    response = requests.get(GOOGLE_GEOCODE_URL, params=params).json()
    print(response)  # Print the full API response for debugging

    if response.get("status") == "OK":
        location_data = response["results"][0]["geometry"]["location"]
        return location_data["lat"], location_data["lng"]

    print("Error fetching coordinates:", response)  # Debugging
    return None, None  # Return None if invalid
def get_route_link(source, destination):
    """Generate Google Maps route link for source to destination."""
    src_lat, src_lng = get_coordinates(source)
    dest_lat, dest_lng = get_coordinates(destination)

    if not src_lat or not dest_lat:
        return None  # If coordinates not found

    return f"https://www.google.com/maps/dir/?api=1&origin={src_lat},{src_lng}&destination={dest_lat},{dest_lng}&travelmode=driving"


def get_aqi(lat, lon):
    """Fetch AQI data for a given location."""
    try:
        response = requests.get(AQI_API_URL.format(lat, lon, AQICN_API_KEY))
        response_json = response.json()

        if "data" in response_json and isinstance(response_json["data"], dict):
            aqi_value = response_json["data"].get("aqi")
            if isinstance(aqi_value, int):  # Ensure AQI is a valid integer
                return aqi_value
            else:
                return random.randint(75, 250)  # Random AQI if response is invalid
        else:
            return random.randint(75, 250)  # Random AQI if API response is not valid
    except:
        return random.randint(75, 250)  # Random AQI in case of API failure


def recommend_transport(aqi):
    """Recommend transport based on AQI."""
    if aqi < 50:
        return "Car/Bike (Good AQI)"
    elif 50 <= aqi < 100:
        return "Bike (Moderate AQI)"
    elif 100 <= aqi < 150:
        return "Public Transport (Unhealthy for sensitive groups)"
    else:
        return "🚨 Strongly prefer Public Transport! Wear a mask! 🚨"

def calculate_coins(aqi):
    """Calculate coin rewards based on AQI."""
    if aqi < 150:
        return random.randint(10, 50)  # Reward between 10-50 coins
    else:
        return 0  # No coins if AQI is too high

@app.route('/')
def index():
    return render_template("index.html")

@app.route('/find_best_route', methods=['GET'])
def find_route():
    source = request.args.get("source")
    destination = request.args.get("destination")

    if not source or not destination:
        return redirect(url_for("index"))  # Redirect to home page if inputs are empty

    # Generate route link
    route_link = get_route_link(source, destination)
    if not route_link:
        return render_template("results.html", error="No suitable route found.")

    # Get AQI based on destination
    dest_lat, dest_lng = get_coordinates(destination)
    aqi = get_aqi(dest_lat, dest_lng)

    # Recommend transport
    transport = recommend_transport(aqi)

    # Calculate coins
    coins = calculate_coins(aqi)

    return render_template("results.html", 
                           route_link=route_link, 
                           aqi=aqi, 
                           transport_recommendation=transport, 
                           coins=f"You can earn {coins} carbon-free coins by traveling on this route!")

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)'''